<?php

namespace Modules\LanguagePack\Database\Seeders;

use Illuminate\Database\Seeder;

class LanguagePackDatabaseSeeder extends Seeder
{

    public function run()
    {
        //
    }

}
