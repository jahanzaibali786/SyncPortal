<?php

return [
    'assets' => [
        'name' => 'e.g. Laptop, iPhone, etc',
    ],
];
