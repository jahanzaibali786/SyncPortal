<?php 
return [
  'assets' => [
    'name' => '예를 들어 노트북, 아이폰 등',
  ],
];