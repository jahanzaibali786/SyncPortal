<?php

return array(
    'otherPaymentMethod' => 'eg. RazorPay, UPI, etc.',
    'payoutDetails' => 'Enter payout details (e.g., PayPal ID, bank details, etc.)',
);
