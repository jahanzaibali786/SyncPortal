<?php

return array(
    'minimumPayout' => 'Minimum Payout',
    'lowestValue' => 'The amount should be at least',
    'MaxValue' => 'The amount should be less or equl to',
    'commissionTypeError' => 'Commision type should be fixed on SignUp',
    'affiliateNotRegistered' => 'No affiliate registered yet',
    'insufficientBalance' => 'Insufficient balance',
    'minimumPayoutMessage' => 'Minimum payout is :min_payout<br> Current balance is :current_balance',
    'alreadyRequested' => 'Already requested for payout',
    'noAffiliate' => 'No affiliate registered yet',
);

