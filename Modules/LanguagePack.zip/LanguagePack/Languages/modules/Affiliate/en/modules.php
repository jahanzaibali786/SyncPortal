<?php

return array(
    'settings' => array(
        'commissionEnabled' => 'Commission Enabled',
        'commissionType' => 'Commission Type',
        'commissionCap' => 'Commission Cap',
        'minimumPayout' => 'Minimum Payout',
        'payoutMethods' => 'Minimum Methods',
    ),
);
