<?php 
return [
  'nameRequired' => 'حقل الاسم مطلوب',
  'emailRequired' => 'حقل البريد الإلكتروني مطلوب',
  'phoneRequired' => 'حقل الهاتف مطلوب',
  'agreementRequired' => 'تحقق من الاتفاقية أعلاه',
  'pageNotFound' => 'الصفحة المطلوبة لا يمكن العثور عليه.',
  'newsLetterSubscribe' => 'لقد تم الاشتراك في النشرة الإخبارية لدينا!',
  'newContactReceived' => 'تم استلام تفاصيل اتصال جديدة',
  'ApiNotAvailable' => 'آسف! هناك مشكلة ما من جانبنا، يرجى المحاولة بعد مرور بعض الوقت.',
];