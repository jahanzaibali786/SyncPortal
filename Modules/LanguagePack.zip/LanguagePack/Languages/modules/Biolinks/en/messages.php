<?php

return array(
    'nameRequired' => 'Name field is required',
    'emailRequired' => 'Email field is required',
    'phoneRequired' => 'Phone filed is required',
    'agreementRequired' => 'Check above agreement',
    'pageNotFound' => 'The requested page could not be found.',
    'newsLetterSubscribe' => 'You have been subscribed to our newsletter!',
    'newContactReceived' => 'New contact detail received',
    'ApiNotAvailable' => 'Sorry! There is some issue at our end, please try after some time.'
);

