<?php 
return [
  'nameRequired' => 'Das Namensfeld ist erforderlich',
  'emailRequired' => 'Das E-Mail-Feld ist erforderlich',
  'phoneRequired' => 'Das Telefonfeld ist erforderlich',
  'agreementRequired' => 'Überprüfen Sie die obige Vereinbarung',
  'pageNotFound' => 'Die angeforderte Seite konnte nicht gefunden werden.',
  'newsLetterSubscribe' => 'Sie haben sich für unseren Newsletter angemeldet!',
  'newContactReceived' => 'Neue Kontaktdaten erhalten',
  'ApiNotAvailable' => 'Entschuldigung! Bei uns gibt es ein Problem. Bitte versuchen Sie es nach einiger Zeit erneut.',
];