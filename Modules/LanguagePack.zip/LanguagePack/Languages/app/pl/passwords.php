<?php 
return [
  'password' => 'Hasła muszą mieć co najmniej sześć znaków i odpowiadać potwierdzeniu.',
  'reset' => 'Twoje hasło zostało zresetowane!. Proszę czekać, za chwilę nastąpi przekierowanie z powrotem na stronę logowania',
  'sent' => 'Sprawdź swoje konto e-mail. Wysłaliśmy e-mailem link do resetowania hasła!',
  'token' => 'Ten token resetowania hasła jest nieprawidłowy.',
  'user' => 'Nie możemy znaleźć użytkownika o tym adresie e-mail.',
  'throttled' => 'Proszę poczekać przed ponowną próbą.',
  'notMatch' => 'Podane hasło nie jest zgodne z bieżącym hasłem.',
];