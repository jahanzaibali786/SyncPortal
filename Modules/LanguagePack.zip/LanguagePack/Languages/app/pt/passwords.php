<?php 
return [
  'password' => 'As senhas devem ter pelo menos seis caracteres e corresponder à confirmação.',
  'reset' => 'Sua senha foi alterada!. Aguarde, você será redirecionado de volta à página de login em breve',
  'sent' => 'Por favor, verifique sua conta de e-mail. Enviamos por e-mail o link de redefinição de senha!',
  'token' => 'Este token de redefinição de senha é inválido.',
  'user' => 'Não conseguimos encontrar um usuário com esse endereço de e-mail.',
  'throttled' => 'Aguarde antes de tentar novamente.',
  'notMatch' => 'A senha fornecida não corresponde à sua senha atual.',
];