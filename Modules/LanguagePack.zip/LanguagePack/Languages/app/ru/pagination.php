<?php 
return [
  'previous' => '" Предыдущий',
  'next' => 'Следующий "',
];