<?php 
return [
  'password' => 'Fjalëkalimet duhet të jenë të paktën gjashtë karaktere dhe të përputhen me konfirmimin.',
  'reset' => 'Fjalëkalimi juaj është rivendosur!. Ju lutemi prisni, do të ridrejtoheni në faqen e identifikimit pas një kohe',
  'sent' => 'Ju lutemi kontrolloni llogarinë tuaj të emailit. Ne kemi dërguar me email lidhjen tuaj të rivendosjes së fjalëkalimit!',
  'token' => 'Ky kod i rivendosjes së fjalëkalimit është i pavlefshëm.',
  'user' => 'Nuk mund të gjejmë një përdorues me atë adresë e-mail.',
  'throttled' => 'Ju lutemi prisni përpara se të provoni përsëri.',
  'notMatch' => 'Fjalëkalimi i dhënë nuk përputhet me fjalëkalimin tuaj aktual.',
];