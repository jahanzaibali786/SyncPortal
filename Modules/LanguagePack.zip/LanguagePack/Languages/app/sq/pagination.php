<?php 
return [
  'previous' => '« E mëparshme',
  'next' => 'Tjetra »',
];