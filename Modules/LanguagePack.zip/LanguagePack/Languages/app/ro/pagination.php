<?php 
return [
  'previous' => '„Anterior',
  'next' => 'Următorul "',
];