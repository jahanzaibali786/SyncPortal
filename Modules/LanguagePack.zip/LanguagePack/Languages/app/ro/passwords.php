<?php 
return [
  'password' => 'Parolele trebuie să aibă cel puțin șase caractere și să se potrivească cu confirmarea.',
  'reset' => 'Parola ta a fost resetata!. Vă rugăm să așteptați, veți fi redirecționat înapoi la pagina de autentificare peste un timp',
  'sent' => 'Vă rugăm să vă verificați contul de e-mail. V-am trimis prin e-mail linkul de resetare a parolei!',
  'token' => 'Acest simbol de resetare a parolei este nevalid.',
  'user' => 'Nu putem găsi un utilizator cu acea adresă de e-mail.',
  'throttled' => 'Vă rugăm să așteptați înainte de a reîncerca.',
  'notMatch' => 'Parola furnizată nu se potrivește cu parola dvs. actuală.',
];