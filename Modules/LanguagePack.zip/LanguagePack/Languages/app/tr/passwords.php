<?php 
return [
  'password' => 'Şifreler en az altı karakterden oluşmalı ve onayla eşleşmelidir.',
  'reset' => 'Şifreniz sıfırlandı!. Lütfen bekleyin, bir süre sonra giriş sayfasına yönlendirileceksiniz.',
  'sent' => 'Lütfen e-posta hesabınızı kontrol edin. Şifre sıfırlama bağlantınızı e-postayla gönderdik!',
  'token' => 'Bu şifre sıfırlama jetonu geçersiz.',
  'user' => 'Bu e-posta adresine sahip bir kullanıcı bulamıyoruz.',
  'throttled' => 'Tekrar denemeden önce lütfen bekleyin.',
  'notMatch' => 'Sağlanan şifre mevcut şifrenizle eşleşmiyor.',
];