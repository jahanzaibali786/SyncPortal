<?php 
return [
  'previous' => '" Öncesi',
  'next' => 'Sonraki "',
];