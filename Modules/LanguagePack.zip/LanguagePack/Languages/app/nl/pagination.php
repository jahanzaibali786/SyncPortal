<?php 
return [
  'previous' => '" Vorig',
  'next' => 'Volgende "',
];