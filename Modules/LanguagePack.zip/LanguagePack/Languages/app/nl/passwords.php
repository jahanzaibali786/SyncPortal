<?php 
return [
  'password' => 'Wachtwoorden moeten minimaal zes tekens lang zijn en overeenkomen met de bevestiging.',
  'reset' => 'Je wachtwoord is gereset!. Een ogenblik geduld, u wordt over een tijdje teruggeleid naar de inlogpagina',
  'sent' => 'Controleer uw e-mailaccount. We hebben uw link voor het opnieuw instellen van uw wachtwoord per e-mail verzonden!',
  'token' => 'Dit token voor het opnieuw instellen van het wachtwoord is ongeldig.',
  'user' => 'We kunnen geen gebruiker met dat e-mailadres vinden.',
  'throttled' => 'Wacht alstublieft voordat u het opnieuw probeert.',
  'notMatch' => 'Het opgegeven wachtwoord komt niet overeen met uw huidige wachtwoord.',
];