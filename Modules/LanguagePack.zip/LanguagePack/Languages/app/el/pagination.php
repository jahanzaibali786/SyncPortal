<?php 
return [
  'previous' => '«Προηγούμενο',
  'next' => 'Επόμενο "',
];