<?php 
return [
  'previous' => '" Претходна',
  'next' => 'Следећи "',
];