<?php 
return [
  'previous' => '" ก่อนหน้า',
  'next' => 'ต่อไป "',
];