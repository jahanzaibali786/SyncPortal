<?php 
return [
  'previous' => '" 이전의',
  'next' => '다음 "',
];