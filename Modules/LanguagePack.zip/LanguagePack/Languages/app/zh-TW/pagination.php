<?php 
return [
  'previous' => '「 以前的',
  'next' => '下一個 ”',
];