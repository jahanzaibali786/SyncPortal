<?php 
return [
  'previous' => '" سابق',
  'next' => 'التالي "',
];