<?php 
return [
  'previous' => '«قبلی',
  'next' => 'بعد "',
];