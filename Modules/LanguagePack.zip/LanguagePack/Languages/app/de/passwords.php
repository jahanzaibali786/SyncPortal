<?php 
return [
  'password' => 'Passwörter müssen mindestens sechs Zeichen lang sein und mit der Bestätigung übereinstimmen.',
  'reset' => 'Dein Passwort wurde zurück gesetzt!. Bitte warten Sie, Sie werden nach einer Weile zurück zur Anmeldeseite weitergeleitet',
  'sent' => 'Bitte überprüfen Sie Ihr E-Mail-Konto. Wir haben Ihren Link zum Zurücksetzen Ihres Passworts per E-Mail verschickt!',
  'token' => 'Dieses Passwort-Reset-Token ist ungültig.',
  'user' => 'Wir können keinen Benutzer mit dieser E-Mail-Adresse finden.',
  'throttled' => 'Bitte warten Sie, bevor Sie es erneut versuchen.',
  'notMatch' => 'Das angegebene Passwort stimmt nicht mit Ihrem aktuellen Passwort überein.',
];