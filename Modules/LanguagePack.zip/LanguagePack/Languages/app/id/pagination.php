<?php 
return [
  'previous' => '" Sebelumnya',
  'next' => 'Berikutnya "',
];