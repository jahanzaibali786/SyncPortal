<?php 
return [
  'password' => 'Kata sandi minimal harus enam karakter dan cocok dengan konfirmasi.',
  'reset' => 'Kata sandi Anda telah disetel ulang!. Harap tunggu, Anda akan diarahkan kembali ke halaman login beberapa saat lagi',
  'sent' => 'Silakan periksa akun email Anda. Kami telah mengirimkan tautan pengaturan ulang kata sandi Anda melalui email!',
  'token' => 'Token pengaturan ulang kata sandi ini tidak valid.',
  'user' => 'Kami tidak dapat menemukan pengguna dengan alamat email itu.',
  'throttled' => 'Harap tunggu sebelum mencoba lagi.',
  'notMatch' => 'Kata sandi yang diberikan tidak cocok dengan kata sandi Anda saat ini.',
];