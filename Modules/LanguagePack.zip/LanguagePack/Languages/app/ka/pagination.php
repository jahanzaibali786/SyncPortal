<?php 
return [
  'previous' => '« წინა',
  'next' => 'შემდეგი »',
];