<?php 
return [
  'password' => 'Mật khẩu phải có ít nhất sáu ký tự và khớp với xác nhận.',
  'reset' => 'Mật khẩu của bạn đã được thiết lập lại!. Vui lòng đợi, lát nữa bạn sẽ được chuyển hướng trở lại trang đăng nhập',
  'sent' => 'Vui lòng kiểm tra tài khoản email của bạn. Chúng tôi đã gửi email liên kết đặt lại mật khẩu của bạn!',
  'token' => 'Mã thông báo đặt lại mật khẩu này không hợp lệ.',
  'user' => 'Chúng tôi không thể tìm thấy người dùng có địa chỉ email đó.',
  'throttled' => 'Vui lòng đợi trước khi thử lại.',
  'notMatch' => 'Mật khẩu được cung cấp không khớp với mật khẩu hiện tại của bạn.',
];