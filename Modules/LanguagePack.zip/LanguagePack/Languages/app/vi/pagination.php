<?php 
return [
  'previous' => '" Trước',
  'next' => 'Kế tiếp "',
];