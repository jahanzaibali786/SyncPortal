<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'These credentials do not match our records.',
    'companyAccountDisabled' => 'Your company account is disabled.',
    'failedLoginDisabled' => 'Login has been disabled by your administrator',
    'failedBlocked' => 'Your account is disabled!. Please contact your administrator to enable it.',
    'failedCompanyUnapproved' => 'Your company is not approved yet!. Please wait for the company approval.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
    'recaptchaFailed' => 'Recaptcha not validated.',
    'sociaLoginFail' => 'Your account does not exist. Please sign up',
    'loginWrongCompany'=> 'You are trying to log in to the wrong company.',
    'signInGoogle' => 'Sign in with Google',
    'signInFacebook' => 'Sign in with Facebook',
    'signInLinkedin' => 'Sign in with LinkedIn',
    'signInTwitter' => 'Sign in with Twitter',
    'useEmail' => 'or, use email address',
    'email' => 'Email Address',
    'next' => 'Next',
];
