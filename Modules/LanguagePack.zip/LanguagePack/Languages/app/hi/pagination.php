<?php 
return [
  'previous' => '" पहले का',
  'next' => 'अगला "',
];