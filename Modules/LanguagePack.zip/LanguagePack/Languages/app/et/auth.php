<?php 
return [
  'failed' => 'Need mandaadid ei ühti meie andmetega.',
  'companyAccountDisabled' => 'Teie ettevõtte konto on keelatud.',
  'failedLoginDisabled' => 'Teie administraator on sisselogimise keelanud',
  'failedBlocked' => 'Teie konto on keelatud!. Selle lubamiseks võtke ühendust oma administraatoriga.',
  'failedCompanyUnapproved' => 'Teie ettevõte pole veel kinnitatud!. Palun oodake ettevõtte kinnitust.',
  'throttle' => 'Liiga palju sisselogimiskatseid. Proovige :seconds sekundi pärast uuesti.',
  'recaptchaFailed' => 'Recaptcha pole kinnitatud.',
  'sociaLoginFail' => 'Teie kontot pole olemas. Palun registreeruge',
  'loginWrongCompany' => 'Üritate sisse logida valesse ettevõttesse.',
  'signInGoogle' => 'Logige sisse Google\'iga',
  'signInFacebook' => 'Logi sisse Facebookiga',
  'signInLinkedin' => 'Logige sisse LinkedIniga',
  'signInTwitter' => 'Logi sisse Twitteriga',
  'useEmail' => 'või kasutage meiliaadressi',
  'email' => 'E-posti aadress',
  'next' => 'Edasi',
];