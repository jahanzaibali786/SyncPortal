<?php 
return [
  'previous' => '«Eelmine',
  'next' => 'Järgmine »',
];