<?php 
return [
  'password' => 'Paroolid peavad koosnema vähemalt kuuest tähemärgist ja ühtima kinnitusega.',
  'reset' => 'Teie parool on lähtestatud!. Palun oodake, teid suunatakse mõne aja pärast tagasi sisselogimislehele',
  'sent' => 'Kontrollige oma meilikontot. Saatsime teie parooli lähtestamise lingi e-kirjaga!',
  'token' => 'See parooli lähtestamise luba on kehtetu.',
  'user' => 'Me ei leia selle e-posti aadressiga kasutajat.',
  'throttled' => 'Palun oodake enne uuesti proovimist.',
  'notMatch' => 'Esitatud parool ei ühti teie praeguse parooliga.',
];