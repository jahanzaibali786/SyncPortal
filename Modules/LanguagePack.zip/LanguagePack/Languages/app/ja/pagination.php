<?php 
return [
  'previous' => '" 前の',
  'next' => '次 "',
];