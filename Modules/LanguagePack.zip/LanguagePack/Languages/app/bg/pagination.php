<?php 
return [
  'previous' => '« Предишен',
  'next' => 'Следващия "',
];