<?php 
return [
  'previous' => '" Precedente',
  'next' => 'Prossimo "',
];