<?php 
return [
  'password' => 'Le password devono contenere almeno sei caratteri e corrispondere alla conferma.',
  'reset' => 'La tua password è stata resettata!. Per favore attendi, tra qualche istante verrai reindirizzato alla pagina di accesso',
  'sent' => 'Controlla il tuo account e-mail. Ti abbiamo inviato via email il link per reimpostare la password!',
  'token' => 'Questo token di reimpostazione della password non è valido.',
  'user' => 'Non riusciamo a trovare un utente con quell\'indirizzo e-mail.',
  'throttled' => 'Si prega di attendere prima di riprovare.',
  'notMatch' => 'La password fornita non corrisponde alla tua password attuale.',
];